package cat.proven.guiprod.model;

/**
 *
 * @author jose
 */
public class Model {
    public static ProductService productService = new ProductService();
}
